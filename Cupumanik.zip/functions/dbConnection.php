<?php
$root = $_SERVER ['DOCUMENT_ROOT'] . "/Cupumanik";
$servername = 'localhost';
$dbname = 'cupumanik';
$dbuser = 'theodorus';
$dbpass = 'pass@word1';
?>